gcc part1.c student.c -o part1
./part1
Remove-Item part1.exe